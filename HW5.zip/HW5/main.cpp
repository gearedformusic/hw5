/*

Main function:

? Create two Client Objects
    o Client1 
    o Client2 
? Create 1 messageSever and 1 encodedServer
? Read the file name from Zybook prompt. The file contains all your inputs.
? The inputs are stored in a file. 
    o The input file is read by the readInputFromFile() defined in utility class 
? Ask if the two clients would like a connection
    o If and only if both clients respond yes will the connection be created
        ? If the connection is to be created, ask if the messages should be encoded.
        ? If response if 'Y' or 'y' messages would be encoded, 
        ? for any response other then Y or y, messages would not be encoded.
    o If one or both of the clients enter no, then the output should contain �No connection made.� without the quotes
? You should accept messages from the clients until someone enters a "*" without the quotes.
? All messages should be entered in all capital letters (test cases will have all
capital letter input, this information is for your own testing)
? printOutput = utilityObj.outputString();
? print the "printOutput" to the terminal

*/
#include <iostream>
#include <ifstream>
#include <string>
int main(){
	
	Client Client1;
	Client Client2;
	
	
	
}
