/*
MessageServer Class -> Inherits from Server

? Public:
    o Default Constructor
           ? Pointers will not point to anything yet
    o Implement establishConnections()
           ? Accepts 2 arguments, the pointers for sender and receiver. This function
             should then set the pointers accordingly.
    o Implement sendMessage()
           ? Accepts one argument, the string to be sent.
           
*/

class MessageServer : public Server{
	public:
		MessageServer();
		void establishConnections(Client* send, Client* recieve);
		void sendMessage(string msg);
	
};
