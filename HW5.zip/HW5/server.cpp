/*
SERVER CLASS

? Abstract Class
? Protected:
    o Pointer ?sender ?of type Client
    o Pointer ?receiver ?of type Client
? Public:
    o Pure virtual function establishConnection()
    o Pure virtual function? sendMessage()
    o swapClients()
        ? This function should be defined within the server.cpp file
*/

abstract class server{
	protected:
		Client* sender;
		Client* receiver;
	public:
		virtual void establishConnection();
		virtual void sendMessage();
		swapClients();
	
};
