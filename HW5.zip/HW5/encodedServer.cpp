/*
EncodedServer Class -> Inherits from Server

? Private:
    o char key? [26?]={'B'?,'A'?,'D'?,'C'?,'F'?,'E'?,'H'?,'G'?,'J'?,'I'?,'L'?,'K'?,'N'?,'M'?,'P'?,'O'?,'R'?,'Q'?,'T'?,'S'?,'V'?,'U'?,'X'?,'W'?,'Z'?,'Y'?};
        ?This key is the same as the key in client for coding and decoding messages.
? Public:
    o Default Constructor
        ? Pointers will not point to anything yet
    o Implement establishConnections()
        ? Accepts 2 arguments- the pointers for sender and receiver. This function should then set the pointers accordingly.
    o Implement sendMessage()
        ? Accepts one argument- the string to be sent.
        ? Will call encodeMessage to change the originally passed message.
    o encodeMessage ()
        ? Returns type string and accepts a single argument of type string.
*/

class EncodedServer : public Server{
	private:
		char key[26] = 'B','A','D','C','F','E','H','G','J','I','L','K','N','M','P','O','R','Q','T','S','V','U','X','W','Z','Y'}
	public:
		EncodedServer();
		void establishConnections(Client* send, Client* recieve);
		void sendMessage(string msg);
		string encodeMessage(string code);
};
