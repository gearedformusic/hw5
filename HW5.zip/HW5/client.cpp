/*
CLIENT CLASS

? Private:
    o Attribute ? id ? of type int
    o Attribute ? message ? of type string
    o Attribute ? possesKey ? of type bool
    o Attribute ? key[26]? of type char
        ? For the purpose of ease,the key will be static for your assignment
        ? key? [26?]={?'B'?,'A'?,'D'?,'C'?,'F'?,'E'?,'H'?,'G'?,'J'?,'I'?,'L'?,'K'?,'N'?,'M'?,'P'?,'O'?,'R'?,'Q'?,'T'?,'S'?,'V'?,'U'?,'X'?,'W'?,'Z'?,'Y'?};
        ?This will create the key in Client and translates to A = B, B = A, D = C and C = D and continue with this pattern. This means that position 0 equals A, 1 = B, 2 = C.

? Public:
    o Parameterized Constructor that takes an int as an argument
        ? The passed int will set the id attribute
    o Mutators
        ? getID � Will return the value of id
        ? setID � Will set the value of id
        ? getMessage � Will return the value of message
        ? setMessage � Will set the value of message
        ? setPossesKey � Will set if the client has access to the key
    o decode()
        ? This function will be called from the getMessage mutator and will check if
          the possesKey is true,and if it is,decodes the message.
*/

class Client{
	private:
		int id;
		string message;
		bool possesKey;
		char key[26] = 'B','A','D','C','F','E','H','G','J','I','L','K','N','M','P','O','R','Q','T','S','V','U','X','W','Z','Y'}

	public:
		Client(int num){
			id = num;
		}
		int getID();			//Will return the value of id
        void setID(); 			//Will set the value of id
        string getMessage(); 	//Will return the value of message
        void setMessage(); 		//Will set the value of message
        void setPossesKey(); 	//Will set if the client has access to the key
		decode();
};
