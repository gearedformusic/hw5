/*

Utility class

?Private:
    o ifstream myfile; // to read the input file
    o string outputFile=""; //to store the output
        ?stores all communication messages between the two clients separated by a comma.
    o string input[100]; // to read every line from file in this array input
    o int number_of_lines ; // contains total number of line in the file
?Public 
    o  encodedConnection(Client , Client , encodedServer , string );
        ?this function performs encoded communication between two clients
        ?If the connection is encoded, you should ask client 1 if client 2 should
         have access to key, and then ask client 2 if client 1 should have access to
         the key.
        ?You should accept messages from the clients until someone enters a "*" without the quotes.
        ?All messages should be entered in all capital letters
        ?After the message has been sent to the other client it should be retrieved from the client via a mutator and appended to an string outputFile with the client who sent the message and then the message. This string(outputFile) is returned back to int main() function.
    o  standardConnection(Client , Client , messageServer , string);
        ?this function performs standard non encoding communication between two clients
        ?You should accept messages from the clients until someone enters a "*" without the quotes.
        ?All messages should be entered in all capital letters
        ?After the message has been sent to the other client it should be retrieved from the client via a mutator and appended to an string outputFile with the client who sent the message and then the message. This string(outputFile) is returned back to int main() function.
    o  string * readInputFromFile(string fileName);
        ? reads input from the file and stores it as a array of strings.
        ? returns the array of string, containing the contents of file inputted.
    o  string outputString(); 
        ? returns the string containing all messages exchanged between two clients.

*/

class Utility{
	private:
		ifstream myfile;
		string outputFile;
		string input[100];
		int number_of_lines;
	public:
		encodedConnection(Client, Client, encodedServer, string)		
		standardConnection(Client , Client , messageServer , string);
		string * readInputFromFile(string fileName);
		string outputString(); 
};
